<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<title> INTE 3510 CODIFICACION I </title>
<body>
    <h1> CURSO INTE 3510L Web Technology and Lab </h1>
    <?php
    readfile("tips.txt")
    ?>
</body>
</html>