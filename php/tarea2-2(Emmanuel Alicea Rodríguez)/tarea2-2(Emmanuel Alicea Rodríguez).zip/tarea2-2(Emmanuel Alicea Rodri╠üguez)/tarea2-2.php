<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tarea 2.2 A</title>
</head>
<body>
    <?php
        $ivu = .11;
        $costo = 2500;
        $total = $ivu * $costo;
        echo "<h1> El total a pagar es: $" . $total . ".00.</h1>";
    ?>
</body>
</html>